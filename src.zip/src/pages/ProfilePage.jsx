import { useState, useRef, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import { LogOut } from "../icons/LogOut";
import { API_CONFIG } from "../config/api.config";
import { userService } from "../services/userService";
import { toast } from "react-toastify";
import { getErrorMessage } from "../utils/errorHandler";

const ProfilePage = () => {
  const [userData, setUserData] = useState(null);
  const [profileDetails, setProfileDetails] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showResumeMenu, setShowResumeMenu] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const resumeInputRef = useRef(null);

  // Fetch profile details from API
  const fetchProfileDetails = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await userService.getProfileDetails();
      if (response.success && response.data) {
        setUserData(response.data.user);
        setProfileDetails(response.data.profileDetails);
      }
    } catch (error) {
      console.error("Error fetching profile details:", error);
      toast.error(getErrorMessage(error, "Failed to load profile"));
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Fetch profile on component mount
  useEffect(() => {
    fetchProfileDetails();
  }, [fetchProfileDetails]);

  // Derived user data for display from API response
  const displayName =
    userData?.fullName ||
    `${userData?.firstName || ""} ${userData?.lastName || ""}`.trim() ||
    "User";
  const displayExperience = userData?.yearsOfExperience
    ? `${userData.yearsOfExperience} years experience`
    : "";
  const displayAddress =
    [userData?.city, userData?.state].filter(Boolean).join(", ") ||
    "Not provided";
  const displayEmail = userData?.email || "Not provided";
  const displayPhone = userData?.phoneNumber || "Not provided";
  const displayRole = userData?.role || "";

  // Resume info from profileDetails (new API structure)
  const resumeData = profileDetails?.resume || null;
  const resumeUrl = resumeData?.fileUrl || null;
  const resumeName = resumeData?.fileName || null;

  // Profile photo URL - append base URL if it's a relative path
  const profilePhotoUrl = userData?.profilePhoto
    ? userData.profilePhoto.startsWith("http")
      ? userData.profilePhoto
      : `${API_CONFIG.BASE_URL}${userData.profilePhoto}`
    : "/avatar-placeholder.png";

  // Handle resume file selection and upload
  const handleResumeUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];
    if (!allowedTypes.includes(file.type)) {
      toast.error("Please upload a PDF or Word document");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size should be less than 5MB");
      return;
    }

    setIsUploading(true);
    try {
      const response = await userService.upload_resume(file);
      if (response.success) {
        toast.success("Resume uploaded successfully");
        // Update local state with the new resume data
        if (response.data?.resume) {
          setProfileDetails((prev) => ({
            ...prev,
            resume: response.data.resume,
          }));
        }
      }
    } catch (error) {
      console.error("Error uploading resume:", error);
      toast.error(getErrorMessage(error, "Failed to upload resume"));
    } finally {
      setIsUploading(false);
      // Reset file input
      if (resumeInputRef.current) {
        resumeInputRef.current.value = "";
      }
    }
  };

  // Trigger file input click
  const triggerResumeUpload = () => {
    setShowResumeMenu(false);
    resumeInputRef.current?.click();
  };

  // Handle resume deletion
  const handleResumeDelete = async () => {
    if (!resumeUrl) return;

    setIsDeleting(true);
    setShowResumeMenu(false);
    try {
      const response = await userService.delete_resume();
      if (response.success) {
        toast.success("Resume deleted successfully");
        // Remove resume from local state
        setProfileDetails((prev) => ({
          ...prev,
          resume: null,
        }));
      }
    } catch (error) {
      console.error("Error deleting resume:", error);
      toast.error(getErrorMessage(error, "Failed to delete resume"));
    } finally {
      setIsDeleting(false);
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="loading-state py-24">
        <div className="loading-spinner"></div>
        <p>Loading your profile...</p>
      </div>
    );
  }

  return (
    <div className="page-shell pb-16">
      {/* Hidden file input for resume upload */}
      <input
        type="file"
        ref={resumeInputRef}
        onChange={handleResumeUpload}
        accept=".pdf,.doc,.docx"
        className="hidden"
      />

      {/* Header */}
      <div className="border-b border-line-weak bg-white">
        <div className="app-container flex flex-col gap-2 py-5 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-bold text-brand-ink">My profile</h1>
          <p className="text-sm text-ink-muted">
            <Link to="/dashboard" className="transition-colors hover:text-brand-action">
              Home
            </Link>{" "}
            / <span className="font-medium text-ink">Profile</span>
          </p>
        </div>
      </div>

      {/* Profile Content */}
      <div className="app-container pt-6 sm:pt-8">
        <div className="mx-auto max-w-[872px] space-y-6">
        {/* Profile Header */}
        <section className="panel flex flex-col items-center justify-between gap-6 p-6 md:flex-row md:items-start">
          <div className="flex flex-col items-center gap-5 text-center md:flex-row md:text-left">
            <div className="h-28 w-28 shrink-0 overflow-hidden rounded-full border-4 border-white bg-surface-raised shadow-card">
              <img
                src={profilePhotoUrl}
                alt={displayName}
                className="h-full w-full object-cover"
                onError={(e) => {
                  e.target.src = "/avatar-placeholder.png";
                }}
              />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-brand-ink md:text-3xl">
                {displayName}
              </h2>
              <p className="mt-1 text-base font-medium text-ink-muted">
                {displayRole} {displayExperience && `• ${displayExperience}`}
              </p>
            </div>
          </div>
          <Link
            to="/dashboard/profile/edit"
            className="btn btn-secondary shrink-0"
          >
            <img src="/Edit.svg" alt="" className="h-4 w-4" />
            Edit profile
          </Link>
        </section>

        {/* Basic Information */}
        <section className="panel p-6">
          <h3 className="section-title mb-5">Basic information</h3>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 md:grid-cols-3">
            <div>
              <p className="field-label">Email address</p>
              <p className="mt-1 break-all text-sm font-semibold text-ink">
                {displayEmail}
              </p>
            </div>
            <div>
              <p className="field-label">Phone number</p>
              <p className="mt-1 text-sm font-semibold text-ink">
                {displayPhone}
              </p>
            </div>
            <div>
              <p className="field-label">Address</p>
              <p className="mt-1 text-sm font-semibold text-ink">
                {displayAddress}
              </p>
            </div>
          </div>

          {/* Resume Section */}
          <div className="mt-6 border-t border-line-weak pt-5">
            <p className="field-label mb-2">Resume</p>
            <div className="flex items-center justify-between rounded-lg border border-line-weak bg-surface-raised p-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center">
                  <img
                    src="/Document.svg"
                    alt="File"
                    className="w-[32px] h-[32px]"
                  />
                </div>
                <div>
                  {resumeUrl && resumeName && (
                    <p className="text-sm font-semibold leading-5 -tracking-[2%] text-secondary pb-[2px]">
                      {resumeName}
                    </p>
                  )}
                  {!resumeUrl && (
                    <p className="text-sm font-normal leading-4 -tracking-[2%] text-ink-muted">
                      No resume uploaded
                    </p>
                  )}
                </div>
              </div>
              <div className="relative">
                <button
                  onClick={() => setShowResumeMenu(!showResumeMenu)}
                  disabled={isUploading}
                  className="flex items-center justify-center hover:bg-brand-tint/50 p-1.5 rounded-[6px] transition cursor-pointer disabled:opacity-50"
                >
                  {isUploading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary"></div>
                  ) : (
                    <img
                      src="/Horizantal_dot.svg"
                      alt="More"
                      className="w-6 h-6"
                    />
                  )}
                </button>
                {showResumeMenu && (
                  <div className="absolute right-0 mt-1 w-[190px] bg-white rounded-[8px] shadow-[0_4px_16px_rgba(0,0,0,0.12)] border border-line py-2 z-10 animate-in fade-in duration-100">
                    <button
                      onClick={triggerResumeUpload}
                      className="flex items-center font-medium leading-5 -tracking-[2%] gap-2 w-full px-4 py-2.5 text-sm text-brand-action hover:bg-brand-tint transition cursor-pointer"
                    >
                      <img src="/Edit.svg" alt="Edit" className="w-5 h-5" />
                      {resumeUrl ? "Update Resume" : "Upload Resume"}
                    </button>
                    {resumeUrl && (
                      <button
                        onClick={handleResumeDelete}
                        disabled={isDeleting}
                        className="flex items-center font-medium leading-5 -tracking-[2%] gap-2 w-full px-4 py-2.5 text-sm text-danger hover:bg-[#0A65CC1A] transition disabled:opacity-50"
                      >
                        {isDeleting ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-danger"></div>
                        ) : (
                          <LogOut />
                        )}
                        {isDeleting ? "Deleting..." : "Delete"}
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Qualifications */}
        <Link
          to="/dashboard/profile/qualifications"
          className="panel panel-hover flex items-center justify-between gap-4 p-6"
        >
          <div>
            <h3 className="section-title">Qualifications</h3>
            <p className="mt-1 text-sm leading-6 text-ink-muted">
              We use these details to show you jobs that match your unique skills and experience.
            </p>
          </div>
          <img
            src="/Right_arrow.svg"
            alt=""
            className="h-5 w-5 shrink-0 text-ink-subtle"
          />
        </Link>

        {/* Job Preferences */}
        <Link
          to="/dashboard/profile/job-preferences"
          className="panel panel-hover flex items-center justify-between gap-4 p-6"
        >
          <div>
            <h3 className="section-title">Job preferences</h3>
            <p className="mt-1 text-sm leading-6 text-ink-muted">
              Set your preferred pay, working hours and job type for better matches.
            </p>
          </div>
          <img
            src="/Right_arrow.svg"
            alt=""
            className="h-5 w-5 shrink-0 text-ink-subtle"
          />
        </Link>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
