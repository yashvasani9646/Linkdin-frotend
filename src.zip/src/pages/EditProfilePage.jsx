import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useProfile } from "../hooks/useProfile";
import { useSelector, useDispatch } from "react-redux";
import { selectUser, updateUser } from "../store/slices/authSlice";
import { userService } from "../services/userService";
import { API_CONFIG } from "../config/api.config";
import { toast } from "react-toastify";
import { getErrorMessage } from "../utils/errorHandler";

const EditProfilePage = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { userProfile, updateProfile } = useProfile();
  const [errors, setErrors] = useState({});
  const [selectedFile, setSelectedFile] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [saveError, setSaveError] = useState("");

  const user = useSelector(selectUser);

  // Helper function to split fullName into first and last name
  const getFirstName = () => {
    if (user?.fullName) {
      const parts = user.fullName.trim().split(" ");
      return parts[0] || "";
    }
    return userProfile.firstName || "";
  };

  const getLastName = () => {
    if (user?.fullName) {
      const parts = user.fullName.trim().split(" ");
      return parts.slice(1).join(" ") || "";
    }
    return userProfile.lastName || "";
  };

  // Profile photo URL - append base URL if it's a relative path
  const getProfilePhotoUrl = () => {
    if (user?.profilePhoto) {
      return user.profilePhoto.startsWith("http")
        ? user.profilePhoto
        : `${API_CONFIG.BASE_URL}${user.profilePhoto}`;
    }
    return user?.avatar || userProfile.avatar || "";
  };

  // Use Redux user data (from API) as primary source, fallback to ProfileContext static data
  const [previewImage, setPreviewImage] = useState(getProfilePhotoUrl());

  // Form state - populated from Redux user data (API) with fallback to static data
  const [formData, setFormData] = useState({
    firstName: getFirstName(),
    lastName: getLastName(),
    phoneNumber:
      user?.phone || user?.phoneNumber || userProfile.phoneNumber || "",
    email: user?.email || userProfile.email || "",
    streetAddress:
      user?.streetAddress ||
      user?.address?.street ||
      userProfile.streetAddress ||
      "",
    city: user?.city || user?.address?.city || userProfile.city || "",
    area:
      user?.area ||
      user?.state ||
      user?.address?.state ||
      userProfile.area ||
      "",
    pincode:
      user?.pincode ||
      user?.zipCode ||
      user?.address?.zipCode ||
      userProfile.pincode ||
      "",
    country:
      user?.country || user?.address?.country || userProfile.country || "",
    avatar: user?.avatar || user?.profilePhoto || userProfile.avatar || "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("File size exceeds 5MB limit");
        return;
      }

      // Store the file for later upload
      setSelectedFile(file);
      const imageUrl = URL.createObjectURL(file);
      setPreviewImage(imageUrl);
      setFormData((prev) => ({
        ...prev,
        avatar: imageUrl,
      }));
    }
  };

  const validate = () => {
    const newErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^\+?[\d\s-]{10,}$/;

    // First Name Validation
    if (!formData.firstName.trim()) {
      newErrors.firstName = "First Name is required";
    } else if (formData.firstName.trim().length < 3) {
      newErrors.firstName = "First Name must be at least 3 characters";
    }

    // Last Name Validation
    if (!formData.lastName.trim()) {
      newErrors.lastName = "Last Name is required";
    } else if (formData.lastName.trim().length < 3) {
      newErrors.lastName = "Last Name must be at least 3 characters";
    }

    // Phone Number Validation
    if (!formData.phoneNumber.trim()) {
      newErrors.phoneNumber = "Phone Number is required";
    } else if (
      !phoneRegex.test(formData.phoneNumber.trim().replace(/\s/g, ""))
    ) {
      newErrors.phoneNumber = "Phone Number must be a valid number";
    }

    // Email Validation
    if (!formData.email.trim()) {
      newErrors.email = "Email Address is required";
    } else if (!emailRegex.test(formData.email.trim())) {
      newErrors.email = "Invalid Email Address";
    }

    // Pincode Validation
    if (formData.pincode && !/^\d{6}$/.test(formData.pincode.trim())) {
      newErrors.pincode = "Pincode must be exactly 6 digits";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaveError("");

    // Validate form before saving
    if (!validate()) {
      return;
    }

    setIsLoading(true);

    try {
      let uploadedPhotoUrl = null;

      // Step 1: Upload photo if a new file was selected
      if (selectedFile) {
        try {
          const photoResponse = await userService.uploadProfilePhoto(
            selectedFile
          );

          if (photoResponse?.data?.url) {
            uploadedPhotoUrl = photoResponse.data.url;
          }
        } catch (photoError) {
          const photoMsg = getErrorMessage(photoError, "Failed to upload photo. Please try again.");
          setSaveError(photoMsg);
          toast.error(photoMsg);
          setIsLoading(false);
          return;
        }
      }

      // Step 2: Save profile data (include profilePhoto if uploaded)
      const payload = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        phoneNumber: formData.phoneNumber,
        email: formData.email,
        streetAddress: formData.streetAddress,
        city: formData.city,
        state: formData.area,
        postcode: formData.pincode,
        country: formData.country,
        // Include the new profile photo URL so it gets saved on the backend
        ...(uploadedPhotoUrl && { profilePhoto: uploadedPhotoUrl }),
      };

      await userService.editProfile(payload);

      // Step 3: Update Redux store with new user data using updateUser (merges instead of replacing)
      const updatedUserData = {
        fullName: `${formData.firstName} ${formData.lastName}`,
        phoneNumber: formData.phoneNumber,
        phone: formData.phoneNumber,
        email: formData.email,
        streetAddress: formData.streetAddress,
        city: formData.city,
        state: formData.area,
        zipCode: formData.pincode,
        country: formData.country,
        // Update profile photo if a new one was uploaded
        ...(uploadedPhotoUrl && { profilePhoto: uploadedPhotoUrl }),
      };

      dispatch(updateUser(updatedUserData));

      // Also update context for consistency
      updateProfile({
        ...formData,
        fullName: `${formData.firstName} ${formData.lastName}`,
        ...(uploadedPhotoUrl && { avatar: uploadedPhotoUrl }),
      });

      toast.success("Profile updated successfully!");
      // Navigate to profile page on success
      navigate("/dashboard/profile");
    } catch (error) {
      const msg = getErrorMessage(error, "Failed to update profile. Please try again.");
      setSaveError(msg);
      toast.error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    navigate("/dashboard/profile");
  };

  return (
    <div className="page-shell pb-16">
      {/* Header */}
      <div className="border-b border-line-weak bg-white">
        <div className="app-container flex flex-col gap-2 py-5 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-bold text-brand-ink">Edit profile</h1>
          <p className="text-sm text-ink-muted">
            <Link to="/dashboard" className="transition-colors hover:text-brand-action">
              Home
            </Link>{" "}
            /{" "}
            <Link to="/dashboard/profile" className="transition-colors hover:text-brand-action">
              Profile
            </Link>{" "}
            / <span className="font-medium text-ink">Edit</span>
          </p>
        </div>
      </div>

      {/* Edit Profile Content */}
      <div className="app-container pt-6 sm:pt-8">
        {/* Header with Back Button */}
        <div className="mb-6 flex items-start gap-3">
          <button
            type="button"
            aria-label="Back to profile"
            onClick={handleCancel}
            className="btn-icon mt-0.5 h-10 w-10 shrink-0"
          >
            <img
              src="/Right_arrow.svg"
              alt=""
              className="h-5 w-5 rotate-180"
            />
          </button>
          <div>
            <h2 className="page-title">Edit profile</h2>
            <p className="page-subtitle">
              Update your personal and professional details anytime.
            </p>
          </div>
        </div>

        {/* Form */}
        <div className="panel mx-auto max-w-[872px] space-y-6 p-5 sm:p-6">
          {/* Row 1: Upload Photo, First Name, Last Name */}
          <div className="flex flex-col md:flex-row gap-6">
            {/* Upload Photo */}
            <div className="mx-auto md:mx-0">
              <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                Upload Photo
              </label>
              <div
                className="w-[200px] h-[143px] relative border-2 border-dashed border-line hover:border-brand-action rounded-[8px] flex flex-col items-center justify-center bg-surface-raised hover:bg-brand-tint/30 cursor-pointer transition overflow-hidden group"
                onClick={() =>
                  document.getElementById("profile-upload").click()
                }
              >
                <input
                  type="file"
                  id="profile-upload"
                  className="hidden"
                  accept=".jpg,.jprg,.png"
                  onChange={handleImageUpload}
                />
                {previewImage ? (
                  <img
                    src={previewImage}
                    alt="Profile Preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <>
                    <img
                      src="/Upload.svg"
                      alt="Upload"
                      className="w-10 h-10 mb-2"
                    />
                    <div className="px-4 text-center">
                      <p className="text-[12px] font-normal leading-5 -tracking-[2%] text-secondary">
                        Browse photo or drop here
                      </p>
                      <p className="text-[10px] font-normal leading-3.5 -tracking-[2%] text-ink-muted mt-1">
                        Max photo size 5 MB.
                      </p>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* First Name */}
            <div className="flex-1 ">
              <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                First Name
              </label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                className={`w-full px-4 py-3 bg-white border ${
                  errors.firstName ? "border-danger ring-1 ring-danger" : "border-line hover:border-ink-subtle"
                } rounded-[8px] text-sm text-ink placeholder:text-ink-subtle outline-none transition mb-2`}
              />
              {errors.firstName && (
                <p className="text-red-500 text-xs mb-4">{errors.firstName}</p>
              )}

              <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                Phone Number
              </label>
              <input
                type="tel"
                name="phoneNumber"
                value={formData.phoneNumber}
                onChange={handleChange}
                className={`w-full px-4 py-3 bg-white border ${
                  errors.phoneNumber ? "border-danger ring-1 ring-danger" : "border-line hover:border-ink-subtle"
                } rounded-[8px] text-sm text-ink placeholder:text-ink-subtle outline-none transition`}
              />
              {errors.phoneNumber && (
                <p className="text-red-500 text-xs mt-1">
                  {errors.phoneNumber}
                </p>
              )}
            </div>

            {/* Last Name */}
            <div className="flex-1">
              <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                Last Name
              </label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                className={`w-full px-4 py-3 bg-white border ${
                  errors.lastName ? "border-danger ring-1 ring-danger" : "border-line hover:border-ink-subtle"
                } rounded-[8px] text-sm text-ink placeholder:text-ink-subtle outline-none transition mb-2`}
              />
              {errors.lastName && (
                <p className="text-red-500 text-xs mb-4">{errors.lastName}</p>
              )}

              <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                Email Address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className={`w-full px-4 py-3 bg-white border ${
                  errors.email ? "border-danger ring-1 ring-danger" : "border-line hover:border-ink-subtle"
                } rounded-[8px] text-sm text-ink placeholder:text-ink-subtle outline-none transition`}
              />
              {errors.email && (
                <p className="text-red-500 text-xs mt-1">{errors.email}</p>
              )}
            </div>
          </div>

          {/* Location Section */}
          <div className="gap-6">
            <h3 className="text-[20px] font-semibold leading-[100%] -tracking-[2%] text-secondary mb-5">
              Location
            </h3>

            {/* Street Address */}
            <div className="mb-5">
              <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                Street Address
              </label>
              <input
                type="text"
                name="streetAddress"
                value={formData.streetAddress}
                onChange={handleChange}
                placeholder="Address"
                className="w-full px-4 py-3 bg-white border border-line hover:border-ink-subtle rounded-[8px] text-sm text-ink placeholder:text-ink-subtle outline-none transition"
              />
            </div>

            {/* City, Area, Pincode, Country */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:flex gap-5">
              <div className="flex-1">
                <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                  City, State
                </label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-white border border-line hover:border-ink-subtle rounded-[8px] text-sm text-ink placeholder:text-ink-subtle outline-none transition"
                />
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                  Area
                </label>
                <input
                  type="text"
                  name="area"
                  value={formData.area}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-white border border-line hover:border-ink-subtle rounded-[8px] text-sm text-ink placeholder:text-ink-subtle outline-none transition"
                />
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                  Pincode
                </label>
                <input
                  type="text"
                  name="pincode"
                  value={formData.pincode}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 bg-white border ${
                    errors.pincode ? "border-danger ring-1 ring-danger" : "border-line hover:border-ink-subtle"
                  } rounded-[8px] text-sm text-ink placeholder:text-ink-subtle outline-none transition`}
                />
                {errors.pincode && (
                  <p className="text-danger text-xs mt-1">
                    {errors.pincode}
                  </p>
                )}
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium leading-[100%] tracking-[0%] text-secondary mb-[5px]">
                  Country
                </label>
                <input
                  type="text"
                  name="country"
                  value={formData.country}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-white border border-line hover:border-ink-subtle rounded-[8px] text-sm text-ink placeholder:text-ink-subtle outline-none transition"
                />
              </div>
            </div>
          </div>

          {/* Error Message */}
          {saveError && (
            <div className="alert alert-error" role="alert">
              {saveError}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 border-t border-line-weak pt-5">
            <button
              type="button"
              onClick={handleCancel}
              disabled={isLoading}
              className="btn btn-secondary"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={isLoading}
              className="btn btn-primary gap-2"
            >
              {isLoading ? (
                <>
                  <svg
                    className="animate-spin h-4 w-4"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Saving...
                </>
              ) : (
                "Save"
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditProfilePage;
