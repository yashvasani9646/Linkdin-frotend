import { useState, useRef, useEffect, useCallback } from "react";
import EmojiPicker from "emoji-picker-react";
import { SearchIcon } from "../icons/SearchIon";
import { Link, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import socketService from "../services/socketService";
import chatService from "../services/chatService";

const MessagePage = () => {
  // Get current user from Redux
  const { user } = useSelector((state) => state.auth);
  const currentUserId = user?._id || user?.id;
  const location = useLocation();

  // Chat list state
  const [chats, setChats] = useState([]);
  const [isLoadingChats, setIsLoadingChats] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  // Selected chat state
  const [selectedChatId, setSelectedChatId] = useState(null);
  const [selectedChat, setSelectedChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);

  // Input state
  const [input, setInput] = useState("");
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isMobileChatOpen, setIsMobileChatOpen] = useState(false);
  const [selectedAttachments, setSelectedAttachments] = useState([]);
  const [uploadingFiles, setUploadingFiles] = useState(false);

  // Typing state
  const [typingUsers, setTypingUsers] = useState({});
  const [isTyping, setIsTyping] = useState(false);
  const typingTimeoutRef = useRef(null);

  // Online users
  const [onlineUsers, setOnlineUsers] = useState(new Set());

  // Refs
  const messagesContainerRef = useRef(null);
  const fileInputRef = useRef(null);

  // Message menu state
  const [openMessageMenu, setOpenMessageMenu] = useState(null);
  const [deletingMessageId, setDeletingMessageId] = useState(null);

  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [uploadingVoice, setUploadingVoice] = useState(false);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const recordingTimerRef = useRef(null);

  // Initialize socket connection
  useEffect(() => {
    const token = localStorage.getItem("accessToken");
    if (token && !socketService.isConnected()) {
      socketService.connect(token);
    }

    return () => {
      // Don't disconnect on unmount - keep connection alive for app
    };
  }, []);

  // Fetch chat list on mount
  useEffect(() => {
    const fetchChats = async () => {
      setIsLoadingChats(true);
      try {
        const response = await chatService.getChats();
        if (response.success && response.data?.chats) {
          setChats(response.data.chats);

          // Check if we have a selectedChatId from navigation (e.g., from JobApplicationsPage)
          const navigatedChatId = location.state?.selectedChatId;

          if (navigatedChatId) {
            // Auto-select the chat passed from navigation
            setSelectedChatId(navigatedChatId);
            setIsMobileChatOpen(true);
          } else if (response.data.chats.length > 0 && !selectedChatId) {
            // Auto-select first chat if available
            setSelectedChatId(response.data.chats[0]._id);
          }
        }
      } catch (error) {
        console.error("Error fetching chats:", error);
        toast.error("Failed to load conversations");
      } finally {
        setIsLoadingChats(false);
      }
    };

    fetchChats();
  }, [location.state?.selectedChatId]);

  // Fetch messages when chat is selected AND join socket room
  useEffect(() => {
    if (!selectedChatId) return;

    const fetchMessages = async () => {
      setIsLoadingMessages(true);
      try {
        const response = await chatService.getChatMessages(selectedChatId);
        if (response.success && response.data) {
          // Reverse messages to show oldest first, newest at bottom (like WhatsApp)
          const messagesFromApi = response.data.messages || [];
          setMessages([...messagesFromApi].reverse());
          setSelectedChat(response.data.chat);

          // ✅ JOIN THE CHAT ROOM after getting chat data
          // Get the other participant's ID from the chat
          const chat = response.data.chat;
          const otherParticipant =
            chat?.otherParticipant ||
            chat?.participants?.find((p) => p._id !== currentUserId);

          if (otherParticipant) {
            socketService.emit("join_chat", {
              recipientId: otherParticipant._id,
              jobId: chat?.job?._id || chat?.jobId,
            });
          }

          // Mark messages as read
          socketService.markAsRead(selectedChatId);

          // Scroll to bottom after messages load
          setTimeout(() => {
            if (messagesContainerRef.current) {
              messagesContainerRef.current.scrollTop =
                messagesContainerRef.current.scrollHeight;
            }
          }, 100);
        }
      } catch (error) {
        console.error("Error fetching messages:", error);
        toast.error("Failed to load messages");
      } finally {
        setIsLoadingMessages(false);
      }
    };

    fetchMessages();

    // ✅ LEAVE THE CHAT ROOM when switching to another chat
    return () => {
      socketService.emit("leave_chat", { chatId: selectedChatId });
    };
  }, [selectedChatId, currentUserId]);

  // Re-join the active chat room after a socket reconnect
  useEffect(() => {
    if (!selectedChat) return;

    const socket = socketService.getSocket();
    if (!socket) return;

    const rejoinChat = () => {
      const otherParticipant =
        selectedChat.otherParticipant ||
        selectedChat.participants?.find((p) => p._id !== currentUserId);

      if (!otherParticipant) return;

      socketService.emit("join_chat", {
        recipientId: otherParticipant._id,
        jobId: selectedChat?.job?._id || selectedChat?.jobId,
      });

      if (selectedChatId) {
        socketService.markAsRead(selectedChatId);
      }
    };

    socket.on("connect", rejoinChat);
    return () => socket.off("connect", rejoinChat);
  }, [selectedChat, selectedChatId, currentUserId]);

  // Socket event listeners
  useEffect(() => {
    // Handle incoming messages
    const handleReceiveMessage = (data) => {
      if (data.chatId === selectedChatId) {
        setMessages((prev) => [...prev, data.message]);
        // Mark as read if chat is open
        socketService.markAsRead(selectedChatId);
      }

      // Update chat list with new message
      setChats((prev) =>
        prev.map((chat) =>
          chat._id === data.chatId
            ? {
                ...chat,
                lastMessage: {
                  content: data.message.content,
                  sentAt: data.message.sentAt,
                  sender: data.message.sender,
                },
                lastMessageAt: data.message.sentAt,
                unreadCount:
                  chat._id === selectedChatId ? 0 : (chat.unreadCount || 0) + 1,
              }
            : chat
        )
      );
    };

    // Handle message sent confirmation
    const handleMessageSent = (data) => {
      setMessages((prev) => [...prev, data.message]);

      // Update chat list
      setChats((prev) =>
        prev.map((chat) =>
          chat._id === data.chatId
            ? {
                ...chat,
                lastMessage: {
                  content: data.message.content,
                  sentAt: data.message.sentAt,
                  sender: data.message.sender,
                },
                lastMessageAt: data.message.sentAt,
              }
            : chat
        )
      );
    };

    // Handle typing indicators
    const handleUserTyping = (data) => {
      setTypingUsers((prev) => ({ ...prev, [data.chatId]: data.userId }));
    };

    const handleUserStoppedTyping = (data) => {
      setTypingUsers((prev) => {
        const updated = { ...prev };
        delete updated[data.chatId];
        return updated;
      });
    };

    // Handle message delivery/read status
    const handleMessageDelivered = (data) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg._id === data.messageId
            ? {
                ...msg,
                isDelivered: true,
                deliveredAt: new Date().toISOString(),
              }
            : msg
        )
      );
    };

    const handleMessagesRead = (data) => {
      if (data.chatId === selectedChatId) {
        setMessages((prev) =>
          prev.map((msg) =>
            msg.sender === currentUserId && !msg.isRead
              ? { ...msg, isRead: true, readAt: new Date().toISOString() }
              : msg
          )
        );
      }
    };

    // Handle online/offline status
    const handleUserOnline = (data) => {
      setOnlineUsers((prev) => new Set([...prev, data.userId]));
    };

    const handleUserOffline = (data) => {
      setOnlineUsers((prev) => {
        const updated = new Set(prev);
        updated.delete(data.userId);
        return updated;
      });
    };

    // Handle errors
    const handleError = (data) => {
      console.error("[Socket] Error:", data);
      toast.error(data.message || "Chat error occurred");
    };

    // Register listeners
    socketService.on("receive_message", handleReceiveMessage);
    socketService.on("message_sent", handleMessageSent);
    socketService.on("user_typing", handleUserTyping);
    socketService.on("user_stopped_typing", handleUserStoppedTyping);
    socketService.on("message_delivered", handleMessageDelivered);
    socketService.on("messages_read", handleMessagesRead);
    socketService.on("user_online", handleUserOnline);
    socketService.on("user_offline", handleUserOffline);
    socketService.on("error", handleError);

    // Cleanup
    return () => {
      socketService.off("receive_message", handleReceiveMessage);
      socketService.off("message_sent", handleMessageSent);
      socketService.off("user_typing", handleUserTyping);
      socketService.off("user_stopped_typing", handleUserStoppedTyping);
      socketService.off("message_delivered", handleMessageDelivered);
      socketService.off("messages_read", handleMessagesRead);
      socketService.off("user_online", handleUserOnline);
      socketService.off("user_offline", handleUserOffline);
      socketService.off("error", handleError);
    };
  }, [selectedChatId, currentUserId]);

  // Auto-scroll to bottom when new messages are added
  useEffect(() => {
    if (messagesContainerRef.current && messages.length > 0) {
      messagesContainerRef.current.scrollTop =
        messagesContainerRef.current.scrollHeight;
    }
  }, [messages]);

  // Close message menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (openMessageMenu && !e.target.closest(".message-menu-container")) {
        setOpenMessageMenu(null);
      }
    };
    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, [openMessageMenu]);

  // Get other participant from selected chat
  const getOtherParticipant = (chat) => {
    if (!chat) return null;
    if (chat.otherParticipant) return chat.otherParticipant;
    if (chat.participants) {
      return chat.participants.find((p) => p._id !== currentUserId);
    }
    return null;
  };

  const selectedParticipant = getOtherParticipant(selectedChat);

  // Handle send message
  const handleSend = useCallback(() => {
    if ((!input.trim() && selectedAttachments.length === 0) || !selectedChatId)
      return;

    // Determine message type based on attachments
    let messageType = "text";
    if (selectedAttachments.length > 0) {
      messageType = selectedAttachments[0].fileType.startsWith("image/")
        ? "image"
        : "document";
    }

    // Send via socket with attachments
    socketService.emit("send_message", {
      chatId: selectedChatId,
      content: input.trim(),
      messageType,
      attachments: selectedAttachments,
    });

    setInput("");
    setSelectedAttachments([]);

    // Stop typing indicator
    if (isTyping) {
      setIsTyping(false);
      socketService.sendStopTyping(selectedChatId);
    }
  }, [input, selectedChatId, isTyping, selectedAttachments]);

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInputChange = (e) => {
    const textarea = e.target;
    setInput(textarea.value);

    textarea.style.height = "auto";
    const lineHeight = 20;
    const maxHeight = lineHeight * 3;
    textarea.style.height = `${Math.min(textarea.scrollHeight, maxHeight)}px`;
    textarea.style.overflowY =
      textarea.scrollHeight > maxHeight ? "auto" : "hidden";

    // Handle typing indicator
    if (selectedChatId && textarea.value.trim()) {
      if (!isTyping) {
        setIsTyping(true);
        socketService.sendTyping(selectedChatId);
      }

      // Clear existing timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }

      // Stop typing after 2 seconds of no input
      typingTimeoutRef.current = setTimeout(() => {
        setIsTyping(false);
        socketService.sendStopTyping(selectedChatId);
      }, 2000);
    }
  };

  const handleEmojiClick = (emoji) => {
    setInput((prev) => prev + emoji);
  };

  // Handle file selection and upload immediately
  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    try {
      setUploadingFiles(true);
      const response = await chatService.uploadAttachments(files);
      if (response.success) {
        setSelectedAttachments((prev) => [
          ...prev,
          ...response.data.attachments,
        ]);
      }
    } catch (error) {
      console.error("Failed to upload attachments:", error);
      toast.error("Failed to upload files");
    } finally {
      setUploadingFiles(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  // Remove an attachment
  const removeAttachment = (index) => {
    setSelectedAttachments((prev) => prev.filter((_, i) => i !== index));
  };

  // Handle delete message
  const handleDeleteMessage = async (messageId) => {
    if (!selectedChatId || !messageId) return;

    setDeletingMessageId(messageId);
    try {
      const response = await chatService.deleteMessage(
        selectedChatId,
        messageId
      );
      if (response.success) {
        // Remove message from local state
        setMessages((prev) => prev.filter((msg) => msg._id !== messageId));
        toast.success("Message deleted successfully");
      }
    } catch (error) {
      console.error("Error deleting message:", error);
      if (error.response?.status === 403) {
        toast.error("You can only delete your own messages");
      } else if (error.response?.status === 404) {
        toast.error("Message not found");
      } else {
        toast.error("Failed to delete message");
      }
    } finally {
      setDeletingMessageId(null);
      setOpenMessageMenu(null);
    }
  };

  // Format recording duration
  const formatRecordingTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // Start voice recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: "audio/webm",
      });
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingDuration(0);

      // Start timer
      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration((prev) => {
          // Max 5 minutes (300 seconds)
          if (prev >= 300) {
            stopRecording();
            return prev;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (error) {
      console.error("Error accessing microphone:", error);
      toast.error("Unable to access microphone. Please check permissions.");
    }
  };

  // Stop voice recording
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream
        .getTracks()
        .forEach((track) => track.stop());
      setIsRecording(false);
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
    }
  };

  // Cancel voice recording
  const cancelRecording = () => {
    stopRecording();
    audioChunksRef.current = [];
    setRecordingDuration(0);
  };

  // Send voice note
  const sendVoiceNote = async () => {
    if (!selectedChatId || audioChunksRef.current.length === 0) return;

    stopRecording();
    setUploadingVoice(true);

    try {
      // Wait a bit for the last chunk to be added
      await new Promise((resolve) => setTimeout(resolve, 100));

      const audioBlob = new Blob(audioChunksRef.current, {
        type: "audio/webm",
      });

      // Upload voice note
      const response = await chatService.uploadVoiceNote(
        audioBlob,
        recordingDuration
      );

      if (response.success && response.data?.attachment) {
        // Send message with voice attachment via socket
        socketService.emit("send_message", {
          chatId: selectedChatId,
          content: "",
          messageType: "voice",
          attachments: [response.data.attachment],
        });
        toast.success("Voice note sent!");
      }
    } catch (error) {
      console.error("Error sending voice note:", error);
      toast.error("Failed to send voice note");
    } finally {
      audioChunksRef.current = [];
      setRecordingDuration(0);
      setUploadingVoice(false);
    }
  };

  // Format time for display
  const formatTime = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  // Format date for chat list
  const formatChatTime = (dateString) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return formatTime(dateString);
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric" });
    }
  };

  // Message status component
  const MessageStatus = ({ message }) => {
    if (message.sender !== currentUserId) return null;

    if (message.isRead) {
      return <span className="text-brand-action text-[10px] ml-1">✓✓</span>;
    }
    if (message.isDelivered) {
      return <span className="text-gray-400 text-[10px] ml-1">✓✓</span>;
    }
    return <span className="text-gray-400 text-[10px] ml-1">✓</span>;
  };

  // Get file type display name
  const getFileTypeName = (fileType) => {
    if (fileType?.startsWith("image/")) return "Image";
    if (fileType === "application/pdf") return "PDF Document";
    if (fileType === "application/msword") return "Word Document";
    if (
      fileType ===
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
      return "Word Document";
    return "File";
  };

  // Render attachment based on type
  const renderAttachment = (attachment, isMe) => {
    const baseUrl =
      import.meta.env.VITE_API_BASE_URL || "http://localhost:5502";
    const fileUrl = attachment.fileUrl?.startsWith("http")
      ? attachment.fileUrl
      : `${baseUrl}${attachment.fileUrl}`;

    // Image preview
    if (attachment.fileType?.startsWith("image/")) {
      return (
        <a
          href={fileUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="block"
        >
          <img
            src={fileUrl}
            alt={attachment.originalName || "Image"}
            className="max-w-[200px] max-h-[200px] rounded-lg object-cover cursor-pointer hover:opacity-90 transition"
            onError={(e) => {
              e.target.style.display = "none";
            }}
          />
        </a>
      );
    }

    // Voice note player
    if (
      attachment.fileType?.startsWith("audio/") ||
      attachment.category === "voice"
    ) {
      const formatDuration = (seconds) => {
        if (!seconds) return "0:00";
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, "0")}`;
      };

      return (
        <div
          className={`flex items-center gap-3 p-3 rounded-lg min-w-[200px] max-w-[280px] ${
            isMe ? "bg-brand-tint" : "bg-white border border-line-weak"
          }`}
        >
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
              isMe ? "bg-brand-action" : "bg-line-weak"
            }`}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              strokeWidth={1.5}
              stroke="currentColor"
              className={`w-5 h-5 ${isMe ? "text-white" : "text-gray-600"}`}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z"
              />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <audio
              controls
              className="w-full h-8"
              style={{ maxWidth: "180px" }}
            >
              <source
                src={fileUrl}
                type={attachment.fileType || "audio/webm"}
              />
              Your browser does not support audio.
            </audio>
            <p
              className={`text-[10px] mt-1 ${
                isMe ? "text-brand" : "text-gray-500"
              }`}
            >
              {attachment.duration
                ? formatDuration(attachment.duration)
                : "Voice note"}
            </p>
          </div>
        </div>
      );
    }

    // Document/File box (like WhatsApp)
    return (
      <a
        href={fileUrl}
        target="_blank"
        rel="noopener noreferrer"
        className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:opacity-80 transition min-w-[200px] ${
          isMe ? "bg-brand-tint" : "bg-white border border-line-weak"
        }`}
      >
        <div
          className={`w-10 h-10 rounded-lg flex items-center justify-center ${
            isMe ? "bg-brand-action" : "bg-line-weak"
          }`}
        >
          <svg
            className="w-5 h-5 text-white"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path
              fillRule="evenodd"
              d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"
              clipRule="evenodd"
            />
          </svg>
        </div>
        <div className="flex-1 min-w-0">
          <p
            className={`text-xs font-semibold ${
              isMe ? "text-brand" : "text-gray-600"
            }`}
          >
            {getFileTypeName(attachment.fileType)}
          </p>
          <p className="text-[10px] text-gray-500 truncate">
            {attachment.originalName || attachment.fileName || "File"}
          </p>
        </div>
      </a>
    );
  };

  // Check if other user is typing in current chat
  const isOtherUserTyping =
    typingUsers[selectedChatId] &&
    typingUsers[selectedChatId] !== currentUserId;

  // Filter chats by search
  const filteredChats = chats.filter((chat) => {
    const participant = getOtherParticipant(chat);
    const name =
      participant?.fullName ||
      `${participant?.firstName || ""} ${participant?.lastName || ""}`;
    return name.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="page-shell pb-8">
      <div className="border-b border-line-weak bg-white">
        <div className="app-container flex flex-col gap-2 py-5 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-xl font-bold text-brand-ink">Messages</h1>
          <p className="text-sm text-ink-muted">
            <Link to="/dashboard" className="transition-colors hover:text-brand-action">
              Home
            </Link>{" "}
            / <span className="font-medium text-ink">Messages</span>
          </p>
        </div>
      </div>

      <div className="app-container-wide pt-4 md:pt-6">
        <div className="flex flex-col gap-4 lg:grid lg:grid-cols-[320px_minmax(0,1fr)]">
          {/* Left: conversations list */}
          <div
            className={`panel flex h-[calc(100vh-180px)] min-h-[420px] w-full flex-col overflow-hidden md:h-[700px] xl:h-[780px] ${
              isMobileChatOpen ? "hidden lg:flex" : "flex"
            }`}
          >
            <div className="border-b border-line-weak p-4">
              <div className="flex h-11 w-full items-center gap-2.5 rounded-lg border border-line-weak bg-surface-raised px-3 text-sm text-ink-muted focus-within:border-brand-action focus-within:ring-2 focus-within:ring-brand-action/15">
                <SearchIcon />
                <input
                  type="text"
                  placeholder="Search conversations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 bg-transparent text-sm font-medium text-ink outline-none placeholder:text-ink-subtle"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {isLoadingChats ? (
                <div className="loading-state py-12">
                  <div className="loading-spinner h-6 w-6"></div>
                  <p>Loading conversations...</p>
                </div>
              ) : filteredChats.length === 0 ? (
                <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
                  <p className="text-sm font-medium text-ink-muted">No conversations yet</p>
                  <p className="mt-1 text-xs text-ink-subtle">
                    Your messages will appear here.
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2 px-5 pb-2 pt-4 text-xs font-semibold uppercase tracking-wide text-ink-subtle">
                    <img
                      src="/allmsg.svg"
                      alt=""
                      className="h-4 w-4"
                    />
                    <span>All messages</span>
                  </div>

                  <div className="p-2">
                    {filteredChats.map((chat) => {
                      const participant = getOtherParticipant(chat);
                      const isActive = chat._id === selectedChatId;
                      const isOnline = onlineUsers.has(participant?._id);
                      const profilePhoto = participant?.profilePhoto
                        ? `${
                            import.meta.env.VITE_API_BASE_URL ||
                            "http://localhost:5502"
                          }${participant.profilePhoto}`
                        : "/Person.svg";

                      return (
                        <button
                          key={chat._id}
                          type="button"
                          onClick={() => {
                            setSelectedChatId(chat._id);
                            setIsMobileChatOpen(true);
                          }}
                          className={`flex w-full cursor-pointer items-start gap-3 rounded-lg px-3 py-3 text-left text-sm transition-colors ${
                            isActive
                              ? "bg-brand-tint text-brand-ink"
                              : "hover:bg-surface-raised"
                          }`}
                        >
                          <div className="relative shrink-0">
                            <img
                              src={profilePhoto}
                              alt={participant?.firstName || "User"}
                              className="h-10 w-10 rounded-full object-cover"
                              onError={(e) => {
                                e.target.src = "/Person.svg";
                              }}
                            />
                            {isOnline && (
                              <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white bg-success"></span>
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2">
                              <span className="truncate text-sm font-semibold text-ink">
                                {participant?.fullName ||
                                  `${participant?.firstName || ""} ${
                                    participant?.lastName || ""
                                  }`}
                              </span>
                              <span className="shrink-0 text-[10px] font-medium text-ink-subtle">
                                {formatChatTime(chat.lastMessageAt)}
                              </span>
                            </div>
                            <div className="mt-0.5 flex items-center justify-between gap-2">
                              <p className="truncate text-xs text-ink-muted">
                                {chat.lastMessage?.content || "No messages yet"}
                              </p>
                              {chat.unreadCount > 0 && (
                                <span className="min-w-[18px] rounded-full bg-brand-action px-1.5 py-0.5 text-center text-[10px] font-bold text-white">
                                  {chat.unreadCount}
                                </span>
                              )}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Right: chat window */}
          <div
            className={`panel h-[calc(100vh-180px)] min-h-[420px] flex-col overflow-hidden md:h-[700px] xl:h-[780px] ${
              isMobileChatOpen ? "flex" : "hidden lg:flex"
            }`}
          >
            {!selectedChatId ? (
              <div className="flex flex-1 flex-col items-center justify-center px-6 text-center">
                <h3 className="text-lg font-semibold text-brand-ink">
                  Select a conversation
                </h3>
                <p className="mt-1 text-sm text-ink-muted">
                  Choose a conversation from the list to start chatting.
                </p>
              </div>
            ) : (
              <>
                {/* Header */}
                <div className="px-4 py-4 h-[72px] border-b border-line-weak flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setIsMobileChatOpen(false)}
                      className="lg:hidden p-1 mr-2 text-gray-600"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth={1.5}
                        stroke="currentColor"
                        className="w-6 h-6"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"
                        />
                      </svg>
                    </button>
                    <div className="relative">
                      <img
                        src={
                          selectedParticipant?.profilePhoto
                            ? `${
                                import.meta.env.VITE_API_BASE_URL ||
                                "http://localhost:5502"
                              }${selectedParticipant.profilePhoto}`
                            : "/Person.svg"
                        }
                        alt={selectedParticipant?.firstName || "User"}
                        className="w-10 h-10 rounded-full object-cover"
                        onError={(e) => {
                          e.target.src = "/Person.svg";
                        }}
                      />
                      {onlineUsers.has(selectedParticipant?._id) && (
                        <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></span>
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-bold leading-[100%] -tracking-[2%] text-secondary">
                        {selectedParticipant?.fullName ||
                          `${selectedParticipant?.firstName || ""} ${
                            selectedParticipant?.lastName || ""
                          }`}
                      </p>
                      <p className="text-[10px] font-medium leading-[100%] -tracking-[2%] text-secondary">
                        {isOtherUserTyping
                          ? "Typing..."
                          : onlineUsers.has(selectedParticipant?._id)
                          ? "Online"
                          : "Offline"}
                      </p>
                    </div>
                  </div>
                  <button className="w-10 h-10 flex cursor-pointer items-center justify-center bg-[#2223250D] rounded-sm ">
                    <img
                      src="/DotsThreeVertical.svg"
                      alt="More options"
                      className="w-6 h-6"
                    />
                  </button>
                </div>

                {/* Messages */}
                <div
                  ref={messagesContainerRef}
                  className="flex-1 px-[30px] pt-[30px] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent"
                >
                  {isLoadingMessages ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    </div>
                  ) : messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-gray-400">
                      <p>No messages here yet...</p>
                      <p className="text-sm">
                        Say hello to start the conversation!
                      </p>
                    </div>
                  ) : (
                    messages.map((msg, index) => {
                      const isMe = msg.sender === currentUserId;
                      const showDateDivider =
                        index === 0 ||
                        new Date(msg.sentAt).toDateString() !==
                          new Date(messages[index - 1]?.sentAt).toDateString();

                      return (
                        <div key={msg._id || index}>
                          {showDateDivider && (
                            <div className="flex items-center gap-3 py-2 mb-5">
                              <div className="flex-1 h-px bg-secondary"></div>
                              <span className="text-[10px] font-extrabold leading-[10px] tracking-[2%] text-secondary">
                                {new Date(msg.sentAt).toDateString() ===
                                new Date().toDateString()
                                  ? "Today"
                                  : new Date(msg.sentAt).toLocaleDateString(
                                      [],
                                      {
                                        weekday: "long",
                                        month: "short",
                                        day: "numeric",
                                      }
                                    )}
                              </span>
                              <div className="flex-1 h-px bg-secondary"></div>
                            </div>
                          )}

                          {isMe ? (
                            <div className="flex justify-end mb-10 group">
                              <div className="flex items-center gap-2">
                                {/* Message menu for own messages */}
                                <div className="relative message-menu-container">
                                  <button
                                    onClick={() =>
                                      setOpenMessageMenu(
                                        openMessageMenu === msg._id
                                          ? null
                                          : msg._id
                                      )
                                    }
                                    className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-gray-200 rounded-full cursor-pointer"
                                  >
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      fill="none"
                                      viewBox="0 0 24 24"
                                      strokeWidth={1.5}
                                      stroke="currentColor"
                                      className="w-4 h-4 text-gray-500"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        d="M12 6.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 12.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 18.75a.75.75 0 110-1.5.75.75 0 010 1.5z"
                                      />
                                    </svg>
                                  </button>
                                  {openMessageMenu === msg._id && (
                                    <div className="absolute right-0 top-full mt-1 bg-white border border-line-weak rounded-lg shadow-lg z-10 min-w-[120px]">
                                      <button
                                        onClick={() =>
                                          handleDeleteMessage(msg._id)
                                        }
                                        disabled={deletingMessageId === msg._id}
                                        className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-2 cursor-pointer disabled:opacity-50"
                                      >
                                        {deletingMessageId === msg._id ? (
                                          <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                                        ) : (
                                          <svg
                                            xmlns="http://www.w3.org/2000/svg"
                                            fill="none"
                                            viewBox="0 0 24 24"
                                            strokeWidth={1.5}
                                            stroke="currentColor"
                                            className="w-4 h-4"
                                          >
                                            <path
                                              strokeLinecap="round"
                                              strokeLinejoin="round"
                                              d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"
                                            />
                                          </svg>
                                        )}
                                        Delete
                                      </button>
                                    </div>
                                  )}
                                </div>
                                <div className="flex flex-col items-end gap-[5px]">
                                  <div className="bg-brand-tint rounded-[10px] px-2 py-2 max-w-[540px]">
                                    {/* Render attachments */}
                                    {msg.attachments &&
                                      msg.attachments.length > 0 && (
                                        <div className="mb-2 space-y-2">
                                          {msg.attachments.map((att, idx) => (
                                            <div key={idx}>
                                              {renderAttachment(att, true)}
                                            </div>
                                          ))}
                                        </div>
                                      )}
                                    {/* Render text content */}
                                    {msg.content && (
                                      <p className="text-[12px] font-medium leading-[20px] -tracking-[2%] text-secondary">
                                        {msg.content}
                                      </p>
                                    )}
                                  </div>
                                  <p className="text-[8px] mr-[4px] font-semibold leading-[100%] -tracking-[2%] text-secondary flex items-center">
                                    {formatTime(msg.sentAt)}
                                    <MessageStatus message={msg} />
                                  </p>
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-start gap-2.5 mb-10">
                              <img
                                src={
                                  selectedParticipant?.profilePhoto
                                    ? `${
                                        import.meta.env.VITE_API_BASE_URL ||
                                        "http://localhost:5502"
                                      }${selectedParticipant.profilePhoto}`
                                    : "/Person.svg"
                                }
                                alt="Avatar"
                                className="w-[30px] h-[30px] mt-[5px] rounded-full shrink-0 object-cover"
                                onError={(e) => {
                                  e.target.src = "/Person.svg";
                                }}
                              />
                              <div className="flex flex-col gap-[5px] max-w-1/2">
                                <div className="bg-surface rounded-[10px] px-3.5 py-2.5 max-w-[540px]">
                                  {/* Render attachments */}
                                  {msg.attachments &&
                                    msg.attachments.length > 0 && (
                                      <div className="mb-2 space-y-2">
                                        {msg.attachments.map((att, idx) => (
                                          <div key={idx}>
                                            {renderAttachment(att, false)}
                                          </div>
                                        ))}
                                      </div>
                                    )}
                                  {/* Render text content */}
                                  {msg.content && (
                                    <p className="text-[12px] font-medium leading-[20px] -tracking-[2%] text-secondary">
                                      {msg.content}
                                    </p>
                                  )}
                                </div>
                                <p className="text-[8px] pl-[2px] font-semibold leading-[100%] -tracking-[2%] text-secondary">
                                  {formatTime(msg.sentAt)}
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}

                  {/* Typing indicator */}
                  {isOtherUserTyping && (
                    <div className="flex items-start gap-2.5 mb-5">
                      <img
                        src={
                          selectedParticipant?.profilePhoto
                            ? `${
                                import.meta.env.VITE_API_BASE_URL ||
                                "http://localhost:5502"
                              }${selectedParticipant.profilePhoto}`
                            : "/Person.svg"
                        }
                        alt="Avatar"
                        className="w-[30px] h-[30px] mt-[5px] rounded-[5px] shrink-0 object-cover"
                        onError={(e) => {
                          e.target.src = "/Person.svg";
                        }}
                      />
                      <div className="bg-surface rounded-[10px] px-3.5 py-2.5">
                        <div className="flex gap-1">
                          <span
                            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                            style={{ animationDelay: "0ms" }}
                          ></span>
                          <span
                            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                            style={{ animationDelay: "150ms" }}
                          ></span>
                          <span
                            className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                            style={{ animationDelay: "300ms" }}
                          ></span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Input */}
                <div className="px-[30px] pb-[30px]">
                  <div className="flex items-center gap-3 h-[52px] relative">
                    <div className="flex-1 flex items-center gap-3 bg-[#2223250D] rounded-sm px-4 py-2 relative">
                      <div className="flex flex-row gap-4">
                        <button
                          type="button"
                          className="text-ink-subtle cursor-pointer"
                          onClick={() => setShowEmojiPicker((prev) => !prev)}
                        >
                          <img
                            src="/SmileySticker.svg"
                            alt="Emoji"
                            className="w-5 h-5"
                          />
                        </button>
                        <button
                          type="button"
                          className="cursor-pointer"
                          onClick={() => fileInputRef.current?.click()}
                          disabled={uploadingFiles}
                        >
                          {uploadingFiles ? (
                            <div className="w-5 h-5 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                          ) : (
                            <img
                              src="/link.svg"
                              alt="Attach"
                              className="w-5 h-5"
                            />
                          )}
                        </button>
                        <input
                          ref={fileInputRef}
                          type="file"
                          multiple
                          accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx"
                          onChange={handleFileSelect}
                          className="hidden"
                        />
                      </div>

                      {/* Selected attachments preview */}
                      {selectedAttachments.length > 0 && (
                        <div className="absolute bottom-full left-0 right-0 mb-2 bg-white border border-line-weak rounded-lg p-3 shadow-lg max-h-[300px] overflow-y-auto">
                          <div className="flex flex-wrap gap-3">
                            {selectedAttachments.map((attachment, index) => (
                              <div key={index} className="relative">
                                {/* Image preview */}
                                {attachment.fileType?.startsWith("image/") ? (
                                  <div className="relative group">
                                    <img
                                      src={`${
                                        import.meta.env.VITE_API_BASE_URL ||
                                        "http://localhost:5502"
                                      }${attachment.fileUrl}`}
                                      alt={attachment.originalName}
                                      className="w-20 h-20 rounded-lg object-cover"
                                    />
                                    <button
                                      onClick={() => removeAttachment(index)}
                                      className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-red-600"
                                    >
                                      ×
                                    </button>
                                  </div>
                                ) : (
                                  /* Document preview box */
                                  <div className="relative flex items-center gap-2 bg-surface p-2 rounded-lg min-w-[150px]">
                                    <div className="w-8 h-8 rounded bg-brand-action flex items-center justify-center">
                                      <svg
                                        className="w-4 h-4 text-white"
                                        fill="currentColor"
                                        viewBox="0 0 20 20"
                                      >
                                        <path
                                          fillRule="evenodd"
                                          d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z"
                                          clipRule="evenodd"
                                        />
                                      </svg>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                      <p className="text-[10px] font-semibold text-gray-600">
                                        {getFileTypeName(attachment.fileType)}
                                      </p>
                                      <p className="text-[9px] text-gray-500 truncate max-w-[100px]">
                                        {attachment.originalName}
                                      </p>
                                    </div>
                                    <button
                                      onClick={() => removeAttachment(index)}
                                      className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-red-600"
                                    >
                                      ×
                                    </button>
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <textarea
                        value={input}
                        onChange={handleInputChange}
                        onKeyDown={handleKeyDown}
                        placeholder="Type your message..."
                        rows={1}
                        className="flex-1 bg-transparent outline-none text-sm text-secondary font-medium resize-none leading-[20px] min-h-[20px] max-h-[60px] overflow-y-auto placeholder:text-[#767F8C80]"
                      />

                      {showEmojiPicker && (
                        <div className="absolute left-0 bottom-[120%] z-20 rounded-lg bg-white shadow-lg border border-line-weak">
                          <EmojiPicker
                            onEmojiClick={(emojiData) =>
                              handleEmojiClick(emojiData.emoji)
                            }
                            searchDisabled
                            skinTonesDisabled
                            height={320}
                            width={260}
                          />
                        </div>
                      )}
                      <div className="flex flex-row gap-5">
                        {isRecording ? (
                          /* Recording UI */
                          <div className="flex items-center gap-3">
                            {/* Cancel button */}
                            <button
                              type="button"
                              onClick={cancelRecording}
                              className="p-1 hover:bg-gray-200 rounded-full cursor-pointer"
                              title="Cancel recording"
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                strokeWidth={1.5}
                                stroke="currentColor"
                                className="w-5 h-5 text-red-500"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  d="M6 18L18 6M6 6l12 12"
                                />
                              </svg>
                            </button>
                            {/* Recording indicator */}
                            <div className="flex items-center gap-2">
                              <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                              <span className="text-sm font-medium text-red-500">
                                {formatRecordingTime(recordingDuration)}
                              </span>
                            </div>
                            {/* Send voice button */}
                            <button
                              type="button"
                              onClick={sendVoiceNote}
                              disabled={uploadingVoice}
                              className="w-10 h-10 flex items-center justify-center rounded-[2px] bg-brand-action text-white hover:bg-brand-action-hover transition cursor-pointer disabled:opacity-50"
                              title="Send voice note"
                            >
                              {uploadingVoice ? (
                                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              ) : (
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  strokeWidth={1.5}
                                  stroke="currentColor"
                                  className="w-5 h-5"
                                >
                                  <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5"
                                  />
                                </svg>
                              )}
                            </button>
                          </div>
                        ) : (
                          /* Normal mic button */
                          <button
                            type="button"
                            onClick={startRecording}
                            className="cursor-pointer hover:bg-gray-200 p-1 rounded-full transition"
                            title="Record voice note"
                          >
                            <img
                              src="/mic.svg"
                              alt="Voice"
                              className="w-5 h-5"
                            />
                          </button>
                        )}
                        <button
                          onClick={handleSend}
                          disabled={
                            (!input.trim() &&
                              selectedAttachments.length === 0) ||
                            uploadingFiles
                          }
                          className="w-10 h-10 flex items-center justify-center rounded-[2px] bg-brand-action text-white hover:bg-brand-action-hover transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          <img
                            src="/Send_btn.svg"
                            alt="Send"
                            className="w-5 h-5"
                          />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessagePage;
