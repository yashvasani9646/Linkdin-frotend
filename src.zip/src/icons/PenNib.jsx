export const PenNib = () => {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M10.875 15C11.9105 15 12.75 14.1605 12.75 13.125C12.75 12.0895 11.9105 11.25 10.875 11.25C9.83947 11.25 9 12.0895 9 13.125C9 14.1605 9.83947 15 10.875 15Z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3.00055 21.0007L9.54917 14.4512"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3.00055 21L16.0736 18.8212C16.2034 18.7995 16.3252 18.7441 16.4269 18.6605C16.5285 18.5768 16.6063 18.4679 16.6525 18.3447L18.7505 12.75L11.2505 5.25L5.65584 7.34802C5.53261 7.39423 5.42371 7.47206 5.34008 7.57368C5.25645 7.6753 5.20103 7.79715 5.17939 7.92697L3.00055 21Z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.7505 12.7499L21.2202 10.2802C21.2899 10.2106 21.3451 10.1279 21.3828 10.0369C21.4205 9.9459 21.4399 9.84838 21.4399 9.74989C21.4399 9.65139 21.4205 9.55387 21.3828 9.46287C21.3451 9.37188 21.2899 9.2892 21.2202 9.21956L14.7809 2.78022C14.6402 2.63956 14.4495 2.56055 14.2505 2.56055C14.0516 2.56055 13.8609 2.63956 13.7202 2.78022L11.2505 5.24989"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
