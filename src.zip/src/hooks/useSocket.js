/**
 * useSocket Hook
 * Custom hook for Socket.IO connection and event handling
 * Based on best practices for real-time chat applications
 */

import { useEffect, useRef, useState, useCallback } from "react";
import { io } from "socket.io-client";
import { API_CONFIG } from "../config/api.config";

export const useSocket = () => {
    const [socket, setSocket] = useState(null);
    const [isConnected, setIsConnected] = useState(false);
    const socketRef = useRef(null);

    useEffect(() => {
        // Get token from localStorage
        const token = localStorage.getItem("accessToken");

        if (!token) {
            return;
        }

        // Create socket connection
        const newSocket = io(API_CONFIG.BASE_URL, {
            auth: {
                token: token,
            },
            extraHeaders: {
                Authorization: `Bearer ${token}`,
            },
            transports: ["websocket", "polling"],
            reconnection: true,
            reconnectionAttempts: 5,
            reconnectionDelay: 1000,
        });

        socketRef.current = newSocket;

        newSocket.on("connect", () => {
            setSocket(newSocket);
            setIsConnected(true);
        });

        newSocket.on("disconnect", () => {
            setIsConnected(false);
        });

        newSocket.on("connect_error", () => {
            setIsConnected(false);
        });

        return () => {
            newSocket.disconnect();
        };
    }, []); // Empty dependency array - only run once on mount

    /**
     * Emit an event to the server
     * Wrapped in useCallback for stable reference
     */
    const emit = useCallback((event, data) => {
        if (socketRef.current?.connected) {
            socketRef.current.emit(event, data);
        }
    }, []);

    /**
     * Listen to an event from the server
     * Wrapped in useCallback for stable reference
     */
    const on = useCallback((event, callback) => {
        if (socketRef.current) {
            socketRef.current.on(event, callback);
        }
    }, []);

    /**
     * Remove event listener
     * Wrapped in useCallback for stable reference
     */
    const off = useCallback((event, callback) => {
        if (socketRef.current) {
            if (callback) {
                socketRef.current.off(event, callback);
            } else {
                socketRef.current.off(event);
            }
        }
    }, []);

    return {
        socket,
        isConnected,
        emit,
        on,
        off,
    };
};
