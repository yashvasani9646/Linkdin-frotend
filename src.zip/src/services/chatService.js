import api from "./api";
import { API_CONFIG } from "../config/api.config";

export const chatService = {
  // Get user's chat list
  getChats: async (page = 1, limit = 20) => {
    try {
      const response = await api.get(API_CONFIG.ENDPOINTS.CHAT.LIST, {
        params: { page, limit }
      });
      return response.data;
    } catch (error) {
      console.error('[chatService] Error fetching chats:', error);
      throw error;
    }
  },

  // Get messages for a specific chat
  getChatMessages: async (chatId, page = 1, limit = 50) => {
    try {
      const url = API_CONFIG.ENDPOINTS.CHAT.MESSAGES.replace(':chatId', chatId);
      const response = await api.get(url, {
        params: { page, limit }
      });
      return response.data;
    } catch (error) {
      console.error('[chatService] Error fetching messages:', error);
      throw error;
    }
  },

  // Create or get existing chat
  createOrGetChat: async (recipientId, jobId) => {
    try {
      const response = await api.post(API_CONFIG.ENDPOINTS.CHAT.CREATE, {
        recipientId,
        jobId
      });
      return response.data;
    } catch (error) {
      console.error('[chatService] Error creating/getting chat:', error);
      throw error;
    }
  },

  /**
   * Initialize or get existing chat (flexible parameter wrapper)
   * @param {Object} data - { recipientId, jobId, participantB, chatType }
   * @returns {Promise} API response
   */
  initChat: async (data) => {
    try {
      const payload = {
        recipientId: data.recipientId || data.participantB,
        jobId: data.jobId
      };
      const response = await api.post(API_CONFIG.ENDPOINTS.CHAT.CREATE, payload);
      return response.data;
    } catch (error) {
      console.error('[chatService] Error in initChat:', error);
      throw error;
    }
  },

  /**
   * Send message with FormData support (for text + media)
   * @param {FormData} formData - Contains chatId, messageText, media
   * @returns {Promise} API response
   */
  sendMessageWithMedia: async (formData) => {
    try {
      const response = await api.post(API_CONFIG.ENDPOINTS.CHAT.UPLOAD_ATTACHMENTS, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      return response.data;
    } catch (error) {
      console.error('[chatService] Error sending media message:', error);
      throw error;
    }
  },

  // Send message via REST (fallback for text-only)
  sendMessage: async (chatId, content, messageType = 'text') => {
    try {
      const url = API_CONFIG.ENDPOINTS.CHAT.MESSAGES.replace(':chatId', chatId);
      const response = await api.post(url, {
        content,
        messageType
      });
      return response.data;
    } catch (error) {
      console.error('[chatService] Error sending message:', error);
      throw error;
    }
  },

  // Mark messages as read (using PUT)
  markAsRead: async (chatId) => {
    try {
      const url = API_CONFIG.ENDPOINTS.CHAT.MARK_READ.replace(':chatId', chatId);
      const response = await api.put(url);
      return response.data;
    } catch (error) {
      console.warn('[chatService] Failed to mark as read (non-critical):', error.message);
      return { success: false, error: error.message };
    }
  },

  /**
   * Toggle pin status of a chat
   * @param {string} chatId - The chat ID
   * @returns {Promise} API response
   */
  togglePinChat: async (chatId) => {
    try {
      const response = await api.patch(`/api/v1/chat/${chatId}/pin`);
      return response.data;
    } catch (error) {
      console.error('[chatService] Error toggling pin:', error);
      throw error;
    }
  },

  // Delete a message
  deleteMessage: async (chatId, messageId) => {
    try {
      const url = API_CONFIG.ENDPOINTS.CHAT.DELETE_MESSAGE
        .replace(':chatId', chatId)
        .replace(':messageId', messageId);
      const response = await api.delete(url);
      return response.data;
    } catch (error) {
      console.error('[chatService] Error deleting message:', error);
      throw error;
    }
  },

  // Get total unread message count
  getUnreadCount: async () => {
    try {
      const response = await api.get(API_CONFIG.ENDPOINTS.CHAT.UNREAD_COUNT);
      return response.data;
    } catch (error) {
      console.error('[chatService] Error getting unread count:', error);
      throw error;
    }
  },

  // Upload attachments for chat (max 5 files, 10MB each)
  uploadAttachments: async (files) => {
    try {
      const formData = new FormData();
      files.forEach((file) => formData.append('attachments', file));
      const response = await api.post(API_CONFIG.ENDPOINTS.CHAT.UPLOAD_ATTACHMENTS, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      return response.data;
    } catch (error) {
      console.error('[chatService] Error uploading attachments:', error);
      throw error;
    }
  },

  // Upload voice note for chat (max 5MB, ~5 minutes)
  uploadVoiceNote: async (voiceBlob, duration) => {
    try {
      const formData = new FormData();
      formData.append('voice', voiceBlob, 'voice-note.webm');
      if (duration) {
        formData.append('duration', duration);
      }
      const response = await api.post(API_CONFIG.ENDPOINTS.CHAT.UPLOAD_VOICE, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      return response.data;
    } catch (error) {
      console.error('[chatService] Error uploading voice note:', error);
      throw error;
    }
  }
};

export default chatService;
