const TopBar = () => {
  return (
    <div className="bg-surface border-b border-gray-200">
      <div className="container mx-auto py-3 px-4 sm:px-6 lg:px-8 max-w-[1500px]">
        <div className="flex justify-end">
          <button className="flex items-center space-x-3 text-sm text-gray-700 hover:text-primary transition">
            <img
              src="/us_flag.svg"
              alt="United States"
              title="United States"
              className="w-6 h-4"
            />
            <span className="font-medium">English</span>
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M19 9l-7 7-7-7"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default TopBar;
