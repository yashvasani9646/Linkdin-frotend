import { useState, useEffect } from "react";
import { ModelCross } from "../icons/ModelCross";

const AddLicenceModal = ({ isOpen, onClose, onSave, initialData }) => {
  const [formData, setFormData] = useState({
    licenceNumber: "",
    expiryMonth: "",
    expiryYear: "",
    doesNotExpire: false,
  });
  const [errors, setErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (isOpen && initialData) {
      setFormData(initialData);
    } else if (isOpen) {
      setFormData({
        licenceNumber: "",
        expiryMonth: "",
        expiryYear: "",
        doesNotExpire: false,
      });
    }
    setErrors({});
  }, [isOpen, initialData]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.licenceNumber.trim())
      newErrors.licenceNumber = "Licence number is required";
    if (!formData.doesNotExpire) {
      if (!formData.expiryMonth)
        newErrors.expiryMonth = "Expiry month is required";
      if (!formData.expiryYear)
        newErrors.expiryYear = "Expiry year is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Parse backend errors and set them to the appropriate fields
  const handleBackendErrors = (errorData) => {
    if (errorData?.errors && Array.isArray(errorData.errors)) {
      const newErrors = {};
      errorData.errors.forEach((err) => {
        const fieldMatch = err.field.match(/\.(\w+)$/);
        if (fieldMatch) {
          let fieldName = fieldMatch[1];
          if (fieldName === "licenseNumber") fieldName = "licenceNumber";
          newErrors[fieldName] = err.message;
        }
      });
      setErrors((prev) => ({ ...prev, ...newErrors }));
    }
  };

  const resetForm = () => {
    setFormData({
      licenceNumber: "",
      expiryMonth: "",
      expiryYear: "",
      doesNotExpire: false,
    });
    setErrors({});
  };

  const handleSave = async () => {
    if (!validate()) return;

    setIsSaving(true);
    try {
      if (onSave) {
        const result = await onSave(formData);
        if (result?.success) {
          resetForm();
          onClose();
        } else if (result?.error) {
          handleBackendErrors(result.error);
        }
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveAndAddAnother = async () => {
    if (!validate()) return;

    setIsSaving(true);
    try {
      if (onSave) {
        const result = await onSave(formData);
        if (result?.success) {
          resetForm();
        } else if (result?.error) {
          handleBackendErrors(result.error);
        }
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    resetForm();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-backdrop">
      <div className="modal-card max-w-lg overflow-y-auto p-5 sm:p-6">
        <button
          type="button"
          onClick={handleCancel}
          disabled={isSaving}
          className="btn-icon absolute right-4 top-4"
          aria-label="Close modal"
        >
          <ModelCross className="h-5 w-5" />
        </button>

        <h2 className="mb-8 pr-12 text-lg font-bold text-brand-ink">
          Add licence
        </h2>

        {/* Form */}
        <div className="space-y-6">
          {/* Licence Number */}
          <div>
            <label className="field-label">
              Licence Number <span className="text-danger">*</span>
            </label>
            <input
              type="text"
              name="licenceNumber"
              value={formData.licenceNumber}
              onChange={handleChange}
              disabled={isSaving}
              placeholder="Enter number"
              className={`w-full px-5 py-[15px] border ${
                errors.licenceNumber ? "border-danger" : "border-line-weak"
              } rounded-sm text-sm font-medium leading-[100%] tracking-[0%] text-secondary placeholder:text-[#767F8C4D] focus:outline-none focus:ring-1 focus:ring-brand-action focus:border-brand-action transition disabled:bg-gray-100`}
            />
            {errors.licenceNumber && (
              <p className="text-danger text-xs mt-1">
                {errors.licenceNumber}
              </p>
            )}
          </div>

          {/* Expiration date */}
          <div className="mb-5">
            <label className="field-label">
              Expiration date{" "}
              {!formData.doesNotExpire && (
                <span className="text-danger">*</span>
              )}
            </label>
            <div className="flex gap-3 md:gap-6">
              {/* Month Select */}
              <div className="flex-1">
                <select
                  name="expiryMonth"
                  value={formData.expiryMonth}
                  onChange={handleChange}
                  disabled={formData.doesNotExpire || isSaving}
                  className={`w-full px-5 py-[15px] border ${
                    errors.expiryMonth ? "border-danger" : "border-line-weak"
                  } rounded-sm text-sm font-medium leading-[100%] tracking-[0%] focus:outline-none focus:ring-1 focus:ring-brand-action focus:border-brand-action transition appearance-none bg-white cursor-pointer ${
                    formData.expiryMonth === ""
                      ? "text-[#767F8C4D]"
                      : "text-secondary"
                  } ${
                    formData.doesNotExpire || isSaving
                      ? "opacity-50 cursor-not-allowed bg-gray-50"
                      : ""
                  }`}
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg width='12' height='8' viewBox='0 0 12 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1.5L6 6.5L11 1.5' stroke='%23767F8C' strokeWidth='1.5' strokeLinecap='round' strokeLinejoin='round'/%3E%3C/svg%3E")`,
                    backgroundRepeat: "no-repeat",
                    backgroundPosition: "right 20px center",
                  }}
                >
                  <option value="">Month</option>
                  {Array.from({ length: 12 }, (_, i) => (
                    <option key={i} value={i + 1} className="text-secondary">
                      {new Date(0, i).toLocaleString("default", {
                        month: "long",
                      })}
                    </option>
                  ))}
                </select>
                {errors.expiryMonth && (
                  <p className="text-danger text-xs mt-1">
                    {errors.expiryMonth}
                  </p>
                )}
              </div>

              {/* Year Select */}
              <div className="flex-1">
                <select
                  name="expiryYear"
                  value={formData.expiryYear}
                  onChange={handleChange}
                  disabled={formData.doesNotExpire || isSaving}
                  className={`w-full px-5 py-[15px] border ${
                    errors.expiryYear ? "border-danger" : "border-line-weak"
                  } rounded-sm text-sm font-medium leading-[100%] tracking-[0%] focus:outline-none focus:ring-1 focus:ring-brand-action focus:border-brand-action transition appearance-none bg-white cursor-pointer ${
                    formData.expiryYear === ""
                      ? "text-[#767F8C4D]"
                      : "text-secondary"
                  } ${
                    formData.doesNotExpire || isSaving
                      ? "opacity-50 cursor-not-allowed bg-gray-50"
                      : ""
                  }`}
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg width='12' height='8' viewBox='0 0 12 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1.5L6 6.5L11 1.5' stroke='%23767F8C' strokeWidth='1.5' strokeLinecap='round' strokeLinejoin='round'/%3E%3C/svg%3E")`,
                    backgroundRepeat: "no-repeat",
                    backgroundPosition: "right 20px center",
                  }}
                >
                  <option value="">Year</option>
                  {Array.from({ length: 20 }, (_, i) => {
                    const year = new Date().getFullYear() + i;
                    return (
                      <option
                        key={year}
                        value={year}
                        className="text-secondary"
                      >
                        {year}
                      </option>
                    );
                  })}
                </select>
                {errors.expiryYear && (
                  <p className="text-danger text-xs mt-1">
                    {errors.expiryYear}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Does not expire Checkbox */}
          <div className="flex items-center gap-3">
            <div className="relative flex items-center">
              <input
                type="checkbox"
                name="doesNotExpire"
                checked={formData.doesNotExpire}
                onChange={handleChange}
                disabled={isSaving}
                id="doesNotExpire"
                className="peer h-5 w-5 cursor-pointer appearance-none rounded border border-line-weak checked:border-brand-action checked:bg-brand-action transition-all disabled:opacity-50"
              />
              <svg
                className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-white opacity-0 peer-checked:opacity-100"
                width="12"
                height="8"
                viewBox="0 0 12 8"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M1 3.5L4.5 7L11 0.5"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <label
              htmlFor="doesNotExpire"
              className="text-sm font-medium leading-[14px] tracking-[0%] text-secondary/80 cursor-pointer select-none"
            >
              Does not expire
            </label>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-3 sm:flex sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={handleCancel}
            disabled={isSaving}
            className="btn btn-secondary order-1 w-full sm:order-none sm:w-auto"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSaveAndAddAnother}
            disabled={isSaving}
            className="btn btn-secondary order-3 col-span-2 w-full sm:order-none sm:w-auto"
          >
            Save & add another
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="btn btn-primary order-2 w-full sm:order-none sm:w-auto"
          >
            {isSaving ? (
              <>
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white"></span>
                Saving...
              </>
            ) : (
              "Save"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddLicenceModal;
