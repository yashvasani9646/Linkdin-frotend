import { Link } from "react-router-dom";
import Logo from "./common/Logo";

const HeroSection = ({ showLogo = false, title, subtitle, button, children }) => {
  return (
    <section className="border-b border-line-weak bg-white px-4 py-12 sm:px-6 sm:py-16 lg:py-20">
      <div className="app-container text-center">
        {showLogo && (
          <div className="mb-5 flex justify-center">
            <Logo size="lg" to="" />
          </div>
        )}

        {title && (
          <h1 className="mx-auto max-w-3xl text-3xl font-bold leading-tight tracking-tight text-brand-ink sm:text-4xl lg:text-5xl">
            {title}
          </h1>
        )}

        {subtitle && (
          <p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-ink-muted sm:text-lg">
            {subtitle}
          </p>
        )}

        {children && <div className="mx-auto mt-8 max-w-4xl sm:mt-10">{children}</div>}

        {button && (
          <div className="mt-6 flex justify-center">
            {button.link ? (
              <Link to={button.link} className="btn btn-primary">
                {button.text}
              </Link>
            ) : (
              <button type="button" onClick={button.onClick} className="btn btn-primary">
                {button.text}
              </button>
            )}
          </div>
        )}
      </div>
    </section>
  );
};

export default HeroSection;
