import { useState, useEffect } from "react";
import { ModelCross } from "../icons/ModelCross";

const AdminEditProfileModal = ({ isOpen, onClose, user, onSave }) => {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "", // Although image shows City / State as one row, I'll store them or just use single field if design suggests. Image shows "City / State" label and two inputs or one? "Sydney" and "New South Wales" are in separate boxes. It says "City / State". I will assume two fields.
    area: "",
    pincode: "",
    country: "",
    avatar: null,
  });

  useEffect(() => {
    if (user) {
      queueMicrotask(() =>
        setFormData({
          name: user.name || "",
          phone: user.phone || "",
          email: user.email || "",
          address: user.address || "",
          city: user.city || "Sydney",
          state: user.state || "New South Wales",
          area: user.area || "",
          pincode: user.pincode || "",
          country: user.country || "Australia",
          avatar: user.avatar || null,
        })
      );
    }
  }, [user]);

  if (!isOpen) return null;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("File size exceeds 5MB limit");
        return;
      }
      const imageUrl = URL.createObjectURL(file);
      setFormData((prev) => ({ ...prev, avatar: imageUrl }));
    }
  };

  const handleSubmit = () => {
    onSave(formData);
    onClose();
  };

  const getInputClass = () => "field-input";

  return (
    <div className="modal-backdrop">
      <div className="modal-card relative max-w-xl">
        <div className="modal-header">
          <h2 className="text-lg font-bold text-brand-ink">Edit Profile</h2>
          <button
            type="button"
            onClick={onClose}
            className="btn-icon shrink-0"
            aria-label="Close modal"
          >
            <ModelCross className="h-5 w-5" />
          </button>
        </div>

        <div className="modal-body space-y-6">
          <div className="space-y-5">
            {/* Upload Photo */}
            <div>
              <label className="field-label">
                Upload Photo
              </label>
              <div
                className="border border-dashed border-line-weak h-[143px] rounded-lg p-8 flex flex-col items-center justify-center bg-white hover:bg-gray-50 transition cursor-pointer overflow-hidden relative"
                onClick={() =>
                  document.getElementById("admin-profile-upload").click()
                }
              >
                {formData.avatar && formData.avatar !== user.avatar ? (
                  <img
                    src={formData.avatar}
                    alt="Profile Preview"
                    className="w-full h-full object-cover absolute inset-0"
                  />
                ) : (
                  <>
                    <img
                      src="/fi_upload-cloud.svg"
                      className="w-10 h-10"
                      alt=""
                    />
                    <p className="text-xs mt-2.5 font-normal leading-5 -tracking-[2%] text-secondary">
                      Browse photo or drop here
                    </p>
                    <p className="text-[10px] font-normal leading-[14px] -tracking-[2%] text-ink-muted">
                      A photo larger than 400 pixels work best. Max photo size 5
                      MB.
                    </p>
                  </>
                )}
                <input
                  type="file"
                  id="admin-profile-upload"
                  className="hidden"
                  accept="image/*"
                  onChange={handleImageUpload}
                />
              </div>
            </div>

            {/* Name */}
            <div>
              <label className="field-label">
                Name
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Name"
                className={getInputClass()}
              />
            </div>

            {/* Phone Number */}
            <div>
              <label className="field-label">
                Phone Number
              </label>
              <input
                type="text"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="Phone Number"
                className={getInputClass()}
              />
            </div>

            {/* Email Address */}
            <div>
              <label className="field-label">
                Email Address
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Email Address"
                className={getInputClass()}
              />
            </div>

            {/* Street Address */}
            <div>
              <label className="field-label">
                Street Address
              </label>
              <input
                type="text"
                name="address"
                value={formData.address}
                onChange={handleChange}
                placeholder="Address"
                className={getInputClass()}
              />
            </div>

            {/* City / State */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="field-label">
                  City / State
                </label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  placeholder="City"
                  className={getInputClass()}
                />
              </div>
              <div>
                {/* Empty label to align? Or just stack? Image shows labels above both. "City / State" covers both? No, layout looks like grid. Let's assume title "City / State" implies grid. */}
                {/* Provided image shows ONE label "City / State" then two inputs underneath side-by-side. OR "City / State" above the left one and "Area" above right? Wait. */}
                {/* Image: "City / State" | "Area" -- Ah, the labels are separate. Row 1: Street Address. Row 2: City / State (Left) | Area (Right) -- Wait input contains "Sydney" and "New South Wales" -- that looks like City AND State. */}
                {/* Let's look closely at image 2. 
                    Row 1: Street Address.
                    Row 2: "City / State" label -> Input "Sydney". "Area" label -> Input "New South Wales". 
                    Wait, "New South Wales" is a state, not an area. Maybe the labels are confusing in design or I am misreading.
                    Actually, Row 2: "City / State" -> "Sydney".  "Area" -> "New South Wales".
                    Row 3: "Pincode" -> "258789". "Country" -> "Australia".
                  */}
                <label className="field-label">
                  Area
                </label>
                <input
                  type="text"
                  name="state" // mapping state to Area field based on image content "New South Wales"
                  value={formData.state}
                  onChange={handleChange}
                  placeholder="State/Area"
                  className={getInputClass()}
                />
              </div>
            </div>

            {/* Pincode / Country */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="field-label">
                  Pincode
                </label>
                <input
                  type="text"
                  name="pincode"
                  value={formData.pincode}
                  onChange={handleChange}
                  placeholder="Pincode"
                  className={getInputClass()}
                />
              </div>
              <div>
                <label className="field-label">
                  Country
                </label>
                <input
                  type="text"
                  name="country"
                  value={formData.country}
                  onChange={handleChange}
                  placeholder="Country"
                  className={getInputClass()}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="modal-footer">
          <button
            type="button"
            onClick={onClose}
            className="btn btn-secondary"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="btn btn-primary"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminEditProfileModal;
