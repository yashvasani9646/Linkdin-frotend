import { useState, useEffect } from "react";
import { ModelCross } from "../icons/ModelCross";

const AddSkillModal = ({ isOpen, onClose, onSave, initialData }) => {
  const [formData, setFormData] = useState({
    skill: "",
    yearsOfExperience: "",
  });
  const [errors, setErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (isOpen && initialData) {
      setFormData(initialData);
    } else if (isOpen) {
      setFormData({ skill: "", yearsOfExperience: "" });
    }
    setErrors({});
  }, [isOpen, initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  // Regex to validate string (letters, spaces, hyphens, apostrophes only)
  const isValidString = (value) => /^[a-zA-Z\s\-'.,&]+$/.test(value);

  const validate = () => {
    const newErrors = {};
    if (!formData.skill.trim()) {
      newErrors.skill = "Skill is required";
    } else if (!isValidString(formData.skill)) {
      newErrors.skill = "Skill must contain only letters";
    }
    if (!formData.yearsOfExperience)
      newErrors.yearsOfExperience = "Years of experience is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Parse backend errors and set them to the appropriate fields
  const handleBackendErrors = (errorData) => {
    if (errorData?.errors && Array.isArray(errorData.errors)) {
      const newErrors = {};
      errorData.errors.forEach((err) => {
        const fieldMatch = err.field.match(/\.(\w+)$/);
        if (fieldMatch) {
          newErrors[fieldMatch[1]] = err.message;
        }
      });
      setErrors((prev) => ({ ...prev, ...newErrors }));
    }
  };

  const handleSave = async () => {
    if (!validate()) return;

    setIsSaving(true);
    try {
      if (onSave) {
        const result = await onSave(formData);
        if (result?.success) {
          onClose();
        } else if (result?.error) {
          handleBackendErrors(result.error);
        }
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveAndAddAnother = async () => {
    if (!validate()) return;

    setIsSaving(true);
    try {
      if (onSave) {
        const result = await onSave(formData);
        if (result?.success) {
          setFormData({
            skill: "",
            yearsOfExperience: "",
          });
          setErrors({});
        } else if (result?.error) {
          handleBackendErrors(result.error);
        }
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setFormData({
      skill: "",
      yearsOfExperience: "",
    });
    setErrors({});
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-backdrop">
      <div className="modal-card max-w-lg overflow-y-auto p-5 sm:p-6">
        <button
          type="button"
          onClick={handleCancel}
          disabled={isSaving}
          className="btn-icon absolute right-4 top-4"
          aria-label="Close modal"
        >
          <ModelCross className="h-5 w-5" />
        </button>

        <h2 className="mb-8 pr-12 text-lg font-bold text-brand-ink">
          Add skill
        </h2>

        {/* Form */}
        <div className="space-y-6">
          {/* Skill */}
          <div>
            <label className="field-label">
              Skill <span className="text-danger">*</span>
            </label>
            <input
              type="text"
              name="skill"
              value={formData.skill}
              onChange={handleChange}
              disabled={isSaving}
              placeholder="Enter skill"
              className={`w-full px-5 py-[15px] border ${
                errors.skill ? "border-danger" : "border-line-weak"
              } rounded-sm text-sm font-medium leading-[100%] tracking-[0%] text-secondary placeholder:text-[#767F8C4D] focus:outline-none focus:ring-1 focus:ring-brand-action focus:border-brand-action transition disabled:bg-gray-100`}
            />
            {errors.skill && (
              <p className="text-danger text-xs mt-1">{errors.skill}</p>
            )}
          </div>

          {/* Years of Experience */}
          <div>
            <label className="field-label">
              Years of experience <span className="text-danger">*</span>
            </label>
            <select
              name="yearsOfExperience"
              value={formData.yearsOfExperience}
              onChange={handleChange}
              disabled={isSaving}
              className={`w-full px-5 py-[15px] border ${
                errors.yearsOfExperience
                  ? "border-danger"
                  : "border-line-weak"
              } rounded-sm text-sm font-medium leading-[100%] tracking-[0%] focus:outline-none focus:ring-1 focus:ring-brand-action focus:border-brand-action transition appearance-none bg-white cursor-pointer disabled:bg-gray-100 ${
                formData.yearsOfExperience === ""
                  ? "text-[#767F8C4D]"
                  : "text-secondary"
              }`}
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='12' height='8' viewBox='0 0 12 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1.5L6 6.5L11 1.5' stroke='%23767F8C' strokeWidth='1.5' strokeLinecap='round' strokeLinejoin='round'/%3E%3C/svg%3E")`,
                backgroundRepeat: "no-repeat",
                backgroundPosition: "right 20px center",
              }}
            >
              <option value="">Select</option>
              <option value="0-1" className="text-secondary">
                0-1 years
              </option>
              <option value="1-3" className="text-secondary">
                1-3 years
              </option>
              <option value="3-5" className="text-secondary">
                3-5 years
              </option>
              <option value="5-10" className="text-secondary">
                5-10 years
              </option>
              <option value="10+" className="text-secondary">
                10+ years
              </option>
            </select>
            {errors.yearsOfExperience && (
              <p className="text-danger text-xs mt-1">
                {errors.yearsOfExperience}
              </p>
            )}
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-3 sm:flex sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={handleCancel}
            disabled={isSaving}
            className="btn btn-secondary order-1 w-full sm:order-none sm:w-auto"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSaveAndAddAnother}
            disabled={isSaving}
            className="btn btn-secondary order-3 col-span-2 w-full sm:order-none sm:w-auto"
          >
            Save & add another
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="btn btn-primary order-2 w-full sm:order-none sm:w-auto"
          >
            {isSaving ? (
              <>
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white"></span>
                Saving...
              </>
            ) : (
              "Save"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddSkillModal;
