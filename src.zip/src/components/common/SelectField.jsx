import { useState, useRef, useEffect } from "react";

const SelectField = ({
  label,
  name,
  value,
  onChange,
  options = [],
  placeholder = "Select an option",
  required = false,
  error = "",
  className = "",
  wrapperClassName = "mb-6",
  disabled = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const selectedOption = options.find(
    (opt) => String(opt.value) === String(value)
  );

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isOpen]);

  const handleSelect = (optionValue) => {
    if (disabled) return;
    if (onChange) {
      onChange({
        target: {
          name,
          value: optionValue,
        },
      });
    }
    setIsOpen(false);
  };

  const handleKeyDown = (e) => {
    if (disabled) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      setIsOpen((prev) => !prev);
    } else if (e.key === "Escape") {
      setIsOpen(false);
    } else if (e.key === "ArrowDown" && isOpen) {
      e.preventDefault();
      const currentIndex = options.findIndex((opt) => String(opt.value) === String(value));
      const nextIndex = currentIndex < options.length - 1 ? currentIndex + 1 : 0;
      handleSelect(options[nextIndex].value);
    } else if (e.key === "ArrowUp" && isOpen) {
      e.preventDefault();
      const currentIndex = options.findIndex((opt) => String(opt.value) === String(value));
      const prevIndex = currentIndex > 0 ? currentIndex - 1 : options.length - 1;
      handleSelect(options[prevIndex].value);
    }
  };

  const hasError = !!error;

  return (
    <div className={wrapperClassName} ref={dropdownRef}>
      {label && (
        <label id={`${name}-label`} className="field-label">
          {label}
          {required && <span className="ml-1 text-danger">*</span>}
        </label>
      )}

      <div className="relative">
        <button
          type="button"
          onClick={() => !disabled && setIsOpen((prev) => !prev)}
          onKeyDown={handleKeyDown}
          disabled={disabled}
          aria-haspopup="listbox"
          aria-expanded={isOpen}
          aria-labelledby={label ? `${name}-label` : undefined}
          aria-invalid={hasError || undefined}
          aria-describedby={hasError ? `${name}-error` : undefined}
          className={`field-input flex min-h-11 cursor-pointer items-center justify-between text-left ${
            hasError
              ? "field-input-error"
              : isOpen
              ? "border-brand-action ring-2 ring-brand-action/20"
              : ""
          } ${disabled ? "cursor-not-allowed bg-surface opacity-60" : ""} ${className}`}
        >
          <span
            className={
              selectedOption && selectedOption.value !== ""
                ? "font-medium text-ink"
                : "text-ink-subtle"
            }
          >
            {selectedOption && selectedOption.value !== ""
              ? selectedOption.label
              : placeholder}
          </span>

          <svg
            className={`h-4 w-4 shrink-0 text-ink-subtle transition-transform duration-200 ${
              isOpen ? "rotate-180 text-brand-action" : ""
            }`}
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 9l-7 7-7-7"
            />
          </svg>
        </button>

        {/* Dropdown Menu */}
        {isOpen && (
          <div
            role="listbox"
            aria-labelledby={label ? `${name}-label` : undefined}
            className="absolute left-0 right-0 top-full z-50 mt-1.5 max-h-60 overflow-y-auto rounded-xl border border-line-weak bg-white py-1.5 shadow-dropdown"
          >
            {options.map((option) => {
              const isSelected = String(option.value) === String(value);
              return (
                <div
                  key={option.value}
                  role="option"
                  aria-selected={isSelected}
                  onClick={() => handleSelect(option.value)}
                  className={`flex cursor-pointer items-center justify-between px-4 py-2.5 text-sm transition-colors ${
                    isSelected
                      ? "bg-brand-tint font-semibold text-brand-action"
                      : "text-ink hover:bg-surface-raised hover:text-brand-ink"
                  }`}
                >
                  <span>{option.label}</span>
                  {isSelected && (
                    <svg
                      className="h-4 w-4 shrink-0 text-brand-action"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2.5}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {hasError && (
        <p id={`${name}-error`} className="field-error">
          <svg
            className="w-3.5 h-3.5 shrink-0"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path
              fillRule="evenodd"
              d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
              clipRule="evenodd"
            />
          </svg>
          <span>{error}</span>
        </p>
      )}
    </div>
  );
};

export default SelectField;
