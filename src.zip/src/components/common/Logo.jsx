import React from "react";
import { Link } from "react-router-dom";

export const Logo = ({
  variant = "blue",
  size = "default",
  className = "",
  to = "/",
}) => {
  const isWhite = variant === "white";
  const textColor = isWhite ? "text-white" : "text-brand";

  const sizeClasses = {
    sm: "text-xl",
    default: "text-2xl md:text-[28px]",
    lg: "text-3xl md:text-4xl",
  };

  const textSize = sizeClasses[size] || sizeClasses.default;

  const content = (
    <span
      className={`font-sans font-bold inline-flex items-center select-none no-underline ${textColor} ${textSize} ${className}`}
      style={{
        letterSpacing: "-0.045em",
        textDecoration: "none",
      }}
      aria-label="Indeed"
    >
      indeed
    </span>
  );

  if (to) {
    return (
      <Link
        to={to}
        className="logo-link inline-flex items-center no-underline hover:no-underline focus:no-underline active:no-underline outline-none focus:outline-none transition-opacity hover:opacity-90"
        style={{ textDecoration: "none" }}
      >
        {content}
      </Link>
    );
  }

  return content;
};

export default Logo;
